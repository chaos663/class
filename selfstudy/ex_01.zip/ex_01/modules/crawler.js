import  puppeteer  from "puppeteer-core";
//puppeteer 다운 받은 것을 임포트 시킨다.
import os from 'os'
import fs from 'fs'

const macUrl = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
// Chrome browser로 실행시킬 것이기에 chrome.exe가 있는 경로를 입력
const whidowsUrl = 'C:/Program Files (x86)/Google/Chrome/Application/Chrome.exe'
const currentOs = os.type()
const launchConfig = {
  headless: false,
  defaultViewport: null,
  ignoreDefaultArgs: ['--disable-extensions'],
  args: [ '--no-sandbox', '--disable-setuid-sandbox', '--disable-notifications', '--disable-extensions'],
  executablePath: currentOs == 'Darwin' ? macUrl : whidowsUrl
}

//전역변수
let browser = null
let page = null
let datas = []
let new_data = []
let finalData = []

// 브라우져 실행함수
const launch = async function(){
    browser = await puppeteer.launch(launchConfig);
    const pages = await browser.pages();
    console.log('page_length:',pages.length)
    page = pages[0]
}

// url 이동
const goto = async function(url){
  return await page.goto(url)
}


// 데이터 뽑기
// waitForSelector('selector')
const getData = async function () {
  await page.waitForSelector("#__next > div.css-mga9c9 > div.css-r90fu0")
  console.log("페이지 잡는중")
  
  const infoArr = await page.evaluate(function (new_data) {
    const a = document.querySelectorAll('.css-y20lcz')
    for(var i = 0; i< a.length; i++){
      var b = a[i]
      var img = b.querySelector(`.image`).getAttribute('src')
      var company = b.querySelector('.css-ofdc17').innerText
      var name = b.querySelector('.product-name').innerText
      var sale = b.querySelector('.css-pzbnhz').innerText
      var price = b.querySelector('.css-128aswt').innerText + '원'
      var review = b.querySelector('.count').innerText + '개'
      var star = b.querySelector('.avg').innerText + '점'
      var jsonData = {
        company,
        name,
        price,
        sale,
        review,
        star,
        img
      }
      new_data.push(jsonData)
    }
    return new_data
  },new_data)
  finalData = finalData.concat(infoArr)
  browser.close()
}

const writeFile = async function(){
  const stringData = JSON.stringify(finalData)
  const exist = fs.existsSync(`./json/TodaysHouse`)
  if(!exist){
    fs.mkdir(`./json/TodaysHouse`, { recursive : true}, function(err){
      console.log(err)
    })
  }

  const filePath = `./json/TodaysHouse.json`

  await fs.writeFileSync(filePath,stringData)

}


export {
  launch,
  goto,
  getData,
  writeFile
}


