import { launch, goto, getData, writeFile } from './modules/crawler.js'



async function main() {
  // 부라우저 실행
  await launch()
  // url 이동
  await goto('https://store.ohou.se/today_deals')
  // data 뽑기
  await getData()
  
  await writeFile()

  process.exit(1)

}
main()